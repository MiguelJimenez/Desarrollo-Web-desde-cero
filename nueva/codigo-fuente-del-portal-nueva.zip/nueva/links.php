<center>
<p>
<a href="update.php">EDITAR</a>&nbsp
<a href="delete.php">APAGAR</a>&nbsp
<a href="search.php">BUSCAR</a>&nbsp
</center>